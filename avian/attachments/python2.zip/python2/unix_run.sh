#!/bin/bash

python2 main.py < sample.in
