#include <iostream>
#include <vector>

using namespace std;

vector<string> encode(int C, int K, int N, string X);

string decode(int C, int K, int N, vector<string> Y, vector<int> I);
