#!/bin/bash

./avian < sample.in
