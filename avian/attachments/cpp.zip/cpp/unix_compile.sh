#!/bin/bash

g++ -O2 -std=c++11 -g runner.cpp avian.cpp -o avian
