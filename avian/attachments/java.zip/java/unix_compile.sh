#!/bin/bash

javac main.java avian.java
