#!/bin/bash

java main < sample.in
