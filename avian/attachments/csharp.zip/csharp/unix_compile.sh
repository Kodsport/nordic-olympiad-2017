#!/bin/bash

/usr/bin/mcs -out:avian.exe -optimize+ -r:System.Numerics Main.cs avian.cs
