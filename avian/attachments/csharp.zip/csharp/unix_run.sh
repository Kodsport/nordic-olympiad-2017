#!/bin/bash

./avian.exe < sample.in
